# TermX — vendor/ 离线自带依赖清单

- 生成日期：2026-11-09
- 生成方式：Bash + curl 下载、7-Zip（26.03）只读解包、系统文件复制
- 安全约束：全程**未运行**任何下载来的 .exe / 安装程序；**未修改** `src/` 下任何文件；NSIS 安装包仅用 `7z l` / `7z x` 静态解包
- 用途：把桌面程序运行所需的原生依赖一次性打包进 `vendor/`，便于离线分发

---

## 一、总览

| 子目录 | 用途 | 文件数 | 精确字节合计 | `du -sh` 磁盘占用 |
|---|---|---:|---:|---:|
| `openssh/` | OpenSSH 客户端工具集 | 13 | 8,251,038 | 7.9 M |
| `runtime/` | MSVC++ 运行时 DLL | 4 | 1,056,272 | 1.1 M |
| `x11/` | VcXsrv Windows X Server 便携版 | 5,260 | 81,115,412 | 92 M |
| `ssh1/` | 支持 SSH-1 的老版 PuTTY plink | 2 | 353,949 | 348 K |
| `fonts/` | 开源等宽 TTF 字体 | 2 | 349,528 | 348 K |

**vendor 合计：89,232,823 字节**（约 89.23 MB / 85.10 MiB），`du -sh` 显示约 **100 M**。
差异来自 `x11/fonts/` 下 4,673 个小字体文件的磁盘块对齐开销。以上统计不含本 `MANIFEST.md` 文件本身。
**6 项要求全部取得可用文件，无任何缺失项，故未写入任何 `UNAVAILABLE.txt`。**

---

## 二、各子目录明细

### 1. `vendor/openssh/` — OpenSSH 客户端（13 个文件，8,251,038 字节）

**用途**：在离线环境发起 SSH 连接、SCP/SFTP 文件传输、密钥生成与管理（ssh、scp、sftp、ssh-keygen、ssh-add、ssh-agent、ssh-keyscan、ssh-pkcs11-helper、ssh-sk-helper、sftp-server）。

**来源**：`C:/Windows/System32/OpenSSH/`（Windows 内置 OpenSSH for Windows，版本随系统）。

**许可证**：OpenSSH 采用 BSD/ISC 风格开源许可；`LICENSE.txt`、`NOTICE.txt` 为官方许可与第三方声明原文，已一并复制。

| 文件 | 大小(字节) | 来源 |
|---|---:|---|
| ssh.exe | 1,246,208 | C:/Windows/System32/OpenSSH/ |
| scp.exe | 430,080 | 同上 |
| sftp.exe | 457,728 | 同上 |
| ssh-keygen.exe | 861,184 | 同上 |
| ssh-add.exe | 602,624 | 同上 |
| ssh-agent.exe | 553,984 | 同上 |
| ssh-keyscan.exe | 661,504 | 同上 |
| ssh-pkcs11-helper.exe | 514,048 | 同上 |
| ssh-sk-helper.exe | 653,312 | 同上 |
| sftp-server.exe | 322,048 | 同上 |
| LICENSE.txt | 18,934 | 同上 |
| NOTICE.txt | 36,008 | 同上 |
| libcrypto.dll | 1,893,376 | C:/Windows/System32/libcrypto.dll（微软签名，2026-11-10 补） |

**按要求排除**（未复制）：`sshd.exe`、`ssh-shellhost.exe`、`sshd_config_default`（服务端程序及配置模板）。

**2026-11-10 补充 libcrypto.dll 说明**：上述 exe 全部依赖无版本号的
`libcrypto.dll`（微软随 2025-08 OpenSSH 更新放在 System32 根目录，LibreSSL 3.8.2，
官方签名），原打包未携带，导致个别设备（如未收到该更新的 Windows 10、或 PATH 上
存在旧版 DLL 的机器）启动 ssh.exe 报「无法定位程序输入点 BN_set_flags」。现随包
携带并与 ssh.exe 同目录放置（DLL 搜索 exe 所在目录最优先），全机型统一加载。
SHA256：4e50e644cb8c983da2d513124c9c3e6ff966d7c8c1e005a8d226851923129d82。
验证：ssh -V → OpenSSH_for_Windows_9.5p1, LibreSSL 3.8.2。

### 2. `vendor/runtime/` — MSVC++ 运行时（4 个文件，1,056,272 字节）

**用途**：为上述原生 .exe 及 `vendor/x11/` 的可执行文件提供 Visual C++ 2015–2022 运行库，保证在未安装 VC 运行库的目标机上可运行。

**来源**：`C:/Windows/System32/`。

**许可证**：Microsoft Visual C++ Redistributable，属微软专有软件，允许随应用程序再分发（受微软软件许可条款约束），非开源。

| 文件 | 大小(字节) | 来源 |
|---|---:|---|
| msvcp140.dll | 557,728 | C:/Windows/System32/ |
| vcruntime140.dll | 124,544 | 同上 |
| vcruntime140_1.dll | 49,792 | 同上 |
| concrt140.dll | 324,208 | 同上 |

### 3. `vendor/x11/` — VcXsrv 便携 X Server（5,260 个文件，81,115,412 字节）

**用途**：在 Windows 上提供 X11 显示服务，用于 X11 转发 / 图形程序显示。主程序为 `vcxsrv.exe`。

**来源 / 获取过程**：
- 下载：`https://sourceforge.net/projects/vcxsrv/files/latest/download`
- 实际文件：`vcxsrv-64.1.20.14.0.installer.exe`（VcXsrv 1.20.14.0, 64-bit, 42,865,185 字节）
- 项目主页：`https://sourceforge.net/projects/vcxsrv/`
- 用 7-Zip 识别为 NSIS 归档，`7z l` 完整列出 5,262 项（无 `Unexpected end of archive`），再 `7z x` 静态解包
- **仅**复制运行 X Server 所需的最小集合：主程序、顶层全部 `.dll`、辅助 `.exe`、配置文件、`fonts/`、`xkbdata/`、`locale/`、`bitmaps/`；**剔除**安装器残留 `uninstall.exe` 与 `$PLUGINSDIR/`
- 全程未执行该安装包或任何解出的 .exe

**许可证**：主体为 MIT / X Window System License（X11 许可）；随附第三方库各自遵循上游许可（OpenSSL、zlib、libxml2、Mesa、libiconv、PuTTY、MSVC 运行时、各字体等）。详见 `x11/LICENSE.txt`；`bitmaps/COPYING` 为该位图目录的版权声明。

**顶层文件（40 个）**：

| 文件 | 大小(字节) | 类别 |
|---|---:|---|
| vcxsrv.exe | 3,767,296 | X Server 主程序 |
| swrast_dri.dll | 10,717,696 | Mesa 软件渲染 |
| libxml2-2.dll | 5,611,732 | 依赖库 |
| libcrypto-1_1-x64.dll | 3,437,568 | OpenSSL |
| libiconv-2.dll | 1,504,719 | 依赖库 |
| xclock.exe | 1,549,824 | 辅助程序 |
| libX11.dll | 1,001,472 | Xlib |
| xcalc.exe | 610,816 | 辅助程序 |
| msvcp140.dll | 565,648 | MSVC 运行时 |
| swrastwgl_dri.dll | 369,152 | Mesa |
| plink.exe | 313,856 | PuTTY（VcXsrv 自带，用于 X11 over SSH） |
| xkbcomp.exe | 305,152 | xkb 编译工具 |
| libXmu.dll | 279,040 | Xmu |
| xlaunch.exe | 179,712 | 启动向导 |
| libxcb.dll | 133,632 | XCB |
| libgcc_s_sjlj-1.dll | 105,984 | 运行时 |
| vcruntime140.dll | 97,168 | MSVC 运行时 |
| zlib1.dll | 89,600 | zlib |
| libwinpthread-1.dll | 72,704 | 运行时 |
| xauth.exe | 46,080 | X 认证 |
| xwininfo.exe | 44,544 | 辅助程序 |
| XErrorDB | 42,077 | 错误数据库 |
| vcruntime140_1.dll | 37,240 | MSVC 运行时 |
| xrdb.exe | 32,256 | 资源数据库 |
| protocol.txt | 25,699 | 协议说明 |
| libXext.dll | 23,040 | Xext |
| XCalc | 22,676 | 应用资源 |
| dxtn.dll | 20,992 | 纹理库 |
| xhost.exe | 17,408 | 访问控制 |
| libXau.dll | 14,848 | Xau |
| XtErrorDB | 13,700 | 错误数据库 |
| XCalc-color | 10,325 | 应用资源 |
| xkeysymdb | 8,881 | 键符号数据库 |
| system.XWinrc | 3,710 | 系统配置 |
| Xcms.txt | 1,723 | 色彩管理 |
| LICENSE.txt | 2,319 | 来源与许可证说明（本任务生成） |
| XClock-color | 245 | 应用资源 |
| X0.hosts | 26 | 主机访问配置 |
| XClock | 20 | 应用资源 |
| font-dirs | 0 | 字体目录占位文件 |

**资源目录（4 个，共 5,220 个文件）**：

| 目录 | 文件数 | 字节合计 | 说明 |
|---|---:|---:|---|
| fonts/ | 4,673 | 44,828,064 | X11 位图/PCF 字体（DejaVu、Terminus 等） |
| xkbdata/ | 294 | 3,768,396 | XKB 键盘布局数据 |
| locale/ | 177 | 1,252,828 | 本地化数据 |
| bitmaps/ | 76 | 185,544 | 位图资源（含 COPYING） |

### 4. `vendor/ssh1/` — SSH-1 支持（2 个文件，353,949 字节）

**用途**：提供仍支持已废弃 SSH-1 协议的 `plink.exe`（现代 OpenSSH 已移除 SSH-1），供连接老旧设备使用。

**来源**：`https://the.earth.li/~sgtatham/putty/0.67/x86/plink.exe`（PuTTY 0.67, x86, 32-bit）。

**许可证**：MIT licence（MIT-like / PuTTY licence），详见 `ssh1/LICENSE.txt`（含官方许可全文，取自 `https://www.chiark.greenend.org.uk/~sgtatham/putty/licence.html`）。

| 文件 | 大小(字节) | 说明 |
|---|---:|---|
| plink.exe | 351,144 | 已校验：> 100 KB，文件头 `4d 5a`（MZ，合法 PE） |
| LICENSE.txt | 2,805 | PuTTY 许可说明 + MIT 许可全文（本任务生成） |

### 5. `vendor/fonts/` — 开源等宽字体（2 个文件，349,528 字节）

**用途**：程序内嵌 / 终端等宽显示用 TTF 字体，文件名统一为 `Mono.ttf`。

**来源**：`https://sourceforge.net/projects/dejavu/files/latest/download` → `dejavu-fonts-ttf-2.37.zip` → `ttf/DejaVuSansMono.ttf`（DejaVu Fonts 2.37）。
（首选的 raw.githubusercontent.com / github.com 链接连接被重置，改用 SourceForge 官方发布包，字体文件与首选候选一致。）

**许可证**：DejaVu 字体许可（基于 Bitstream Vera Fonts Copyright 与 Arev Fonts Copyright 的宽松开源许可，允许自由使用与再分发），全文见 `fonts/DejaVu-LICENSE.txt`（取自 2.37 发布包内 LICENSE）。

| 文件 | 大小(字节) | 说明 |
|---|---:|---|
| Mono.ttf | 340,712 | 已校验：> 100 KB，文件头 `00 01 00 00`（合法 TrueType sfnt） |
| DejaVu-LICENSE.txt | 8,816 | DejaVu 官方 LICENSE 原文 |

---

## 三、未获取 / 缺失项

**无功能性缺失**：6 项要求全部取得可用文件，因此未创建任何 `UNAVAILABLE.txt`。

过程中的替代与重试（均已成功，仅记录备查）：

1. **字体**：`raw.githubusercontent.com` 与 `github.com` 的 DejaVu / Cascadia 链接均连接被重置或空回复；改用 SourceForge 的 DejaVu 2.37 官方 zip 解包取得 `DejaVuSansMono.ttf`。
2. **VcXsrv**：首次下载在 120s 超时仅得 26,394,624 / 42,865,185 字节的不完整 NSIS 包（7z 报 `Unexpected end of archive`）；重新完整下载后解包成功（5,262 项）。
3. **PuTTY LICENSE**：`putty-0.67.tar.gz` 源码包下载超时、chiark 的 releases 路径返回 404；改用官方可访问的 `licence.html` 提取 MIT 许可全文写入 `ssh1/LICENSE.txt`。
4. **SSH-1 plink**：优先候选（the.earth.li 0.67）首个即成功，备用 URL 未使用。
5. **VcXsrv 便携构建**：未采用 GitHub 便携构建或第三方便携 zip，因 SourceForge installer 已可完整解包出全部运行文件，且版本（1.20.14.0）比便携包（1.17.2.0）更新、依赖更全。
   补充：协作者提供的 `build/x11_probe/portable.zip`（4,514,328 B）经 `7z l` 校验为下载截断（`Unexpected end of archive`，声明压缩数据 5,398,175 B 大于实际文件大小，声明 268 文件/61 文件夹），不可用；同目录 `vcxsrv_installer.exe`（26,787,840 B）亦不完整（官方完整包 42,865,185 B）。故以本目录的官方解包版定稿，未做覆盖以免混入旧版/缺文件。

---

## 四、校验摘要

| 校验项 | 结果 |
|---|---|
| `ssh1/plink.exe` 大小 > 100 KB 且 MZ 头 | 通过（351,144 B，`4d 5a`） |
| `fonts/Mono.ttf` 大小 > 100 KB 且合法 TTF 头 | 通过（340,712 B，`00 01 00 00`） |
| VcXsrv 安装包完整性 | 通过（42,865,185 B，`7z l` 列出 5,262 项无截断错误） |
| `openssh/` 未包含 sshd.exe / ssh-shellhost.exe / sshd_config_default | 通过 |
| 未运行任何下载的 .exe / 安装程序 | 通过（仅 7z 解包 + cp） |
| 未修改 `src/` | 通过 |
